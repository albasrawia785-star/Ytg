package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bluetooth.BluetoothManager
import com.example.bluetooth.BluetoothService
import com.example.data.database.AppDatabase
import com.example.data.database.ChatMessageEntity
import com.example.data.repository.ChatRepository
import com.example.model.BluetoothDeviceDomain
import com.example.model.ConnectionState
import com.example.model.ConversationSummary
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val bluetoothManager = BluetoothManager(application)
    private val bluetoothService = BluetoothService(application, bluetoothManager)
    val repository = ChatRepository(application, database.chatMessageDao(), bluetoothService)

    val connectionState: StateFlow<ConnectionState> = repository.connectionState
    val scannedDevices: StateFlow<List<BluetoothDeviceDomain>> = repository.scannedDevices
    val isScanning: StateFlow<Boolean> = repository.isScanning
    val isBluetoothEnabled: StateFlow<Boolean> = repository.isBluetoothEnabled
    val isPartnerTyping: StateFlow<Boolean> = repository.isPartnerTyping

    private val _pairedDevices = MutableStateFlow<List<BluetoothDeviceDomain>>(emptyList())
    val pairedDevices: StateFlow<List<BluetoothDeviceDomain>> = _pairedDevices.asStateFlow()

    private val _currentPartnerAddress = MutableStateFlow("")
    val currentPartnerAddress: StateFlow<String> = _currentPartnerAddress.asStateFlow()

    private val _currentPartnerName = MutableStateFlow("")
    val currentPartnerName: StateFlow<String> = _currentPartnerName.asStateFlow()

    private val _messageInput = MutableStateFlow("")
    val messageInput: StateFlow<String> = _messageInput.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var typingDebounceJob: Job? = null

    // Searchable and sorted conversation summaries
    val conversations: StateFlow<List<ConversationSummary>> = combine(
        repository.conversations,
        _searchQuery
    ) { convList, query ->
        if (query.isBlank()) {
            convList
        } else {
            convList.filter {
                it.partnerName.contains(query, ignoreCase = true) ||
                it.lastMessageText.contains(query, ignoreCase = true) ||
                it.partnerAddress.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessageEntity>> = _currentPartnerAddress
        .flatMapLatest { partnerAddress ->
            if (partnerAddress.isNotBlank()) {
                repository.getMessagesForPartner(partnerAddress)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        refreshPairedDevices()

        // Observe connection state to update current partner address & mark as read
        viewModelScope.launch {
            connectionState.collect { state ->
                if (state is ConnectionState.Connected) {
                    val partner = state.device
                    _currentPartnerAddress.value = partner.address
                    _currentPartnerName.value = partner.name ?: partner.address
                    repository.setActiveChatPartner(partner.address)
                }
            }
        }
    }

    fun selectConversation(summary: ConversationSummary) {
        _currentPartnerAddress.value = summary.partnerAddress
        _currentPartnerName.value = summary.partnerName
        repository.setActiveChatPartner(summary.partnerAddress)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun refreshPairedDevices() {
        _pairedDevices.value = repository.getPairedDevices()
    }

    fun startHost() {
        repository.startHost()
    }

    fun startScan() {
        refreshPairedDevices()
        repository.startScan()
    }

    fun stopScan() {
        repository.stopScan()
    }

    fun connectToDevice(device: BluetoothDeviceDomain) {
        _currentPartnerAddress.value = device.address
        _currentPartnerName.value = device.name ?: device.address
        repository.setActiveChatPartner(device.address)
        repository.connectToDevice(device)
    }

    fun onMessageInputChanged(text: String) {
        _messageInput.value = text

        // Trigger typing status
        typingDebounceJob?.cancel()
        repository.sendTypingStatus(true)
        typingDebounceJob = viewModelScope.launch {
            delay(1500)
            repository.sendTypingStatus(false)
        }
    }

    fun sendMessage() {
        val text = _messageInput.value.trim()
        if (text.isBlank()) return

        val partnerAddress = _currentPartnerAddress.value
        val partnerName = _currentPartnerName.value

        viewModelScope.launch {
            val success = repository.sendMessage(text, partnerAddress, partnerName)
            if (success) {
                _messageInput.value = ""
                typingDebounceJob?.cancel()
                repository.sendTypingStatus(false)
            } else {
                _errorMessage.value = "فشل إرسال الرسالة. أعد الاتصال وحاول مجدداً."
            }
        }
    }

    fun reconnect() {
        repository.reconnect()
    }

    fun disconnect() {
        repository.setActiveChatPartner("")
        repository.disconnect()
    }

    fun clearHistory() {
        val address = _currentPartnerAddress.value
        if (address.isNotBlank()) {
            deleteConversation(address)
        }
    }

    fun deleteConversation(partnerAddress: String) {
        viewModelScope.launch {
            repository.clearHistory(partnerAddress)
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            repository.clearAllHistory()
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        bluetoothService.onDestroy()
    }
}
