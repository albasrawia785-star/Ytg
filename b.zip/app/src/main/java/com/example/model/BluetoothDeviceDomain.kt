package com.example.model

data class BluetoothDeviceDomain(
    val name: String?,
    val address: String
)
