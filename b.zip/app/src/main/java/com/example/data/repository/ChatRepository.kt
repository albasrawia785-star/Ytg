package com.example.data.repository

import android.content.Context
import com.example.bluetooth.BluetoothService
import com.example.data.database.ChatMessageDao
import com.example.data.database.ChatMessageEntity
import com.example.model.BluetoothDeviceDomain
import com.example.model.ConnectionState
import com.example.model.ConversationSummary
import com.example.model.PacketType
import com.example.utils.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class ChatRepository(
    private val context: Context,
    private val dao: ChatMessageDao,
    val bluetoothService: BluetoothService
) {
    private val repoScope = CoroutineScope(Dispatchers.IO + Job())

    val connectionState: StateFlow<ConnectionState> = bluetoothService.connectionState
    val scannedDevices: StateFlow<List<BluetoothDeviceDomain>> = bluetoothService.bluetoothManager.scannedDevices
    val isScanning: StateFlow<Boolean> = bluetoothService.bluetoothManager.isScanning
    val isBluetoothEnabled: StateFlow<Boolean> = bluetoothService.bluetoothManager.isBluetoothEnabled
    val isPartnerTyping: StateFlow<Boolean> = bluetoothService.isPartnerTyping

    private val _activeChatPartnerAddress = MutableStateFlow("")
    val activeChatPartnerAddress: StateFlow<String> = _activeChatPartnerAddress.asStateFlow()

    init {
        NotificationHelper.createNotificationChannel(context)

        // Observe incoming Bluetooth packets
        repoScope.launch {
            bluetoothService.receivedPackets.collect { packet ->
                when (packet.type) {
                    PacketType.CHAT -> {
                        val activePartner = _activeChatPartnerAddress.value
                        val isCurrentChatActive = (activePartner == packet.senderAddress)

                        val entity = ChatMessageEntity(
                            id = packet.id,
                            senderAddress = packet.senderAddress,
                            senderName = packet.senderName,
                            text = packet.text,
                            timestamp = packet.timestamp,
                            isFromMe = false,
                            isDelivered = true,
                            isRead = isCurrentChatActive,
                            chatPartnerAddress = packet.senderAddress
                        )
                        dao.insertMessage(entity)

                        if (!isCurrentChatActive) {
                            NotificationHelper.showMessageNotification(
                                context = context,
                                senderName = packet.senderName,
                                messageText = packet.text
                            )
                        }
                    }
                    PacketType.ACK -> {
                        if (packet.ackMessageId.isNotBlank()) {
                            dao.markMessageDelivered(packet.ackMessageId)
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    fun setActiveChatPartner(partnerAddress: String) {
        _activeChatPartnerAddress.value = partnerAddress
        if (partnerAddress.isNotBlank()) {
            repoScope.launch {
                dao.markMessagesAsReadForPartner(partnerAddress)
            }
        }
    }

    val conversations: Flow<List<ConversationSummary>> = dao.getAllMessages().map { allMsgs ->
        allMsgs.groupBy { it.chatPartnerAddress }
            .map { (partnerAddress, msgs) ->
                val lastMsg = msgs.maxByOrNull { it.timestamp }!!
                val partnerName = msgs.firstOrNull { !it.isFromMe && it.senderName.isNotBlank() }?.senderName
                    ?: lastMsg.senderName.ifBlank { partnerAddress }
                val unreadCount = msgs.count { !it.isFromMe && !it.isRead }

                ConversationSummary(
                    partnerAddress = partnerAddress,
                    partnerName = partnerName,
                    lastMessageText = lastMsg.text,
                    lastMessageTimestamp = lastMsg.timestamp,
                    unreadCount = unreadCount
                )
            }
            .sortedByDescending { it.lastMessageTimestamp }
    }

    fun getMessagesForPartner(partnerAddress: String): Flow<List<ChatMessageEntity>> {
        return dao.getMessagesForPartner(partnerAddress)
    }

    suspend fun sendMessage(text: String, partnerAddress: String, partnerName: String): Boolean {
        val messageId = UUID.randomUUID().toString()
        val timestamp = System.currentTimeMillis()

        val myAddress = bluetoothService.bluetoothManager.getMyDeviceAddress()
        val myName = bluetoothService.bluetoothManager.getMyDeviceName()

        val entity = ChatMessageEntity(
            id = messageId,
            senderAddress = myAddress,
            senderName = myName,
            text = text,
            timestamp = timestamp,
            isFromMe = true,
            isDelivered = false,
            isRead = true,
            chatPartnerAddress = partnerAddress.ifBlank { "UNKNOWN_DEVICE" }
        )

        dao.insertMessage(entity)

        val success = bluetoothService.sendChatMessage(id = messageId, text = text)
        return success
    }

    fun sendTypingStatus(isTyping: Boolean) {
        bluetoothService.sendTypingStatus(isTyping)
    }

    fun startHost() {
        bluetoothService.startHost()
    }

    fun connectToDevice(device: BluetoothDeviceDomain) {
        bluetoothService.connectToDevice(device)
    }

    fun startScan() {
        bluetoothService.bluetoothManager.startDiscovery()
    }

    fun stopScan() {
        bluetoothService.bluetoothManager.stopDiscovery()
    }

    fun getPairedDevices(): List<BluetoothDeviceDomain> {
        return bluetoothService.bluetoothManager.getPairedDevices()
    }

    fun reconnect() {
        bluetoothService.reconnect()
    }

    fun disconnect() {
        bluetoothService.disconnect()
    }

    suspend fun clearHistory(partnerAddress: String) {
        dao.clearMessagesForPartner(partnerAddress)
    }

    suspend fun clearAllHistory() {
        dao.clearAllMessages()
    }
}
