package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {

    @Query("SELECT * FROM chat_messages WHERE chatPartnerAddress = :partnerAddress ORDER BY timestamp ASC")
    fun getMessagesForPartner(partnerAddress: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<ChatMessageEntity>)

    @Query("UPDATE chat_messages SET isDelivered = 1 WHERE id = :messageId")
    suspend fun markMessageDelivered(messageId: String)

    @Query("UPDATE chat_messages SET isRead = 1 WHERE chatPartnerAddress = :partnerAddress AND isFromMe = 0")
    suspend fun markMessagesAsReadForPartner(partnerAddress: String)

    @Query("DELETE FROM chat_messages WHERE chatPartnerAddress = :partnerAddress")
    suspend fun clearMessagesForPartner(partnerAddress: String)

    @Query("DELETE FROM chat_messages")
    suspend fun clearAllMessages()
}
