package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import com.example.model.BluetoothDeviceDomain
import com.example.utils.PermissionUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class BluetoothManager(private val context: Context) {
    private val TAG = "BluetoothManager"

    val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private val _scannedDevices = MutableStateFlow<List<BluetoothDeviceDomain>>(emptyList())
    val scannedDevices: StateFlow<List<BluetoothDeviceDomain>> = _scannedDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(adapter?.isEnabled == true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val foundDevicesMap = mutableMapOf<String, BluetoothDeviceDomain>()

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    device?.let {
                        val name = try { it.name } catch (e: SecurityException) { null }
                        val domain = BluetoothDeviceDomain(
                            name = name ?: "جهاز مجهول",
                            address = it.address
                        )
                        foundDevicesMap[it.address] = domain
                        _scannedDevices.value = foundDevicesMap.values.toList()
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    _isScanning.value = true
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _isScanning.value = false
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    _isBluetoothEnabled.value = (state == BluetoothAdapter.STATE_ON)
                }
            }
        }
    }

    fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        try {
            context.registerReceiver(receiver, filter)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register receiver: ${e.message}")
        }
    }

    fun unregisterReceiver() {
        try {
            context.unregisterReceiver(receiver)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to unregister receiver: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDeviceDomain> {
        if (!PermissionUtils.hasBluetoothPermissions(context) || adapter == null || !adapter.isEnabled) {
            return emptyList()
        }
        return try {
            adapter.bondedDevices.map { device ->
                BluetoothDeviceDomain(
                    name = device.name ?: "جهاز مقترن",
                    address = device.address
                )
            }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        if (!PermissionUtils.hasBluetoothPermissions(context) || adapter == null || !adapter.isEnabled) {
            return
        }
        try {
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
            }
            foundDevicesMap.clear()
            _scannedDevices.value = emptyList()
            adapter.startDiscovery()
        } catch (e: Exception) {
            Log.e(TAG, "Start discovery error: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        if (!PermissionUtils.hasBluetoothPermissions(context) || adapter == null) return
        try {
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Stop discovery error: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun getDeviceByAddress(address: String): BluetoothDevice? {
        if (adapter == null) return null
        return try {
            adapter.getRemoteDevice(address)
        } catch (e: Exception) {
            null
        }
    }

    @SuppressLint("MissingPermission")
    fun getMyDeviceName(): String {
        if (adapter == null) return "جهازي"
        return try {
            adapter.name ?: "جهازي"
        } catch (e: SecurityException) {
            "جهازي"
        }
    }

    @SuppressLint("MissingPermission")
    fun getMyDeviceAddress(): String {
        if (adapter == null) return "LOCAL_DEVICE"
        return try {
            adapter.address ?: "LOCAL_DEVICE"
        } catch (e: SecurityException) {
            "LOCAL_DEVICE"
        }
    }
}
