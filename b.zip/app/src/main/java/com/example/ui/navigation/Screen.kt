package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Conversations : Screen("conversations_screen")
    object Home : Screen("home_screen")
    object Scan : Screen("scan_screen")
    object Chat : Screen("chat_screen")
}
